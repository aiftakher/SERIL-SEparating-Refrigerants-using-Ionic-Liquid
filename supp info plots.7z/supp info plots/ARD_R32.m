clc
clear all
close all
mat = xlsread('data_hmimBF4_R32.xlsx');
TT = mat(:,1);
PP = mat(:,2);
XX = mat(:,3);
ARD = 0;
for i= 1:length(TT)
    T = TT(i);
    R = 8.314;
    A1 = 9.49117;
    B1 = 3006.86;
    C1 = 37.1416;
    a = 0.750;
    P1_s = exp(A1 - B1/(T+C1)); %Mpa
    V0 = 254.08 / (1.3537 -0.0007*T); %cm^3/mol
    V1 = (1 - a)*V0;
    x1 = XX(i);
    

    tau120 = -2.67023463;
    tau121 = -171.5750104;
    tau210 = 3.16666852;
    tau211 = 1116.885455;

    tau12 = tau120 + tau121/T;
    tau21 = tau210 + tau211/T;

    G12 = exp(-0.2*tau12);
    G21 = exp(-0.2*tau21);

    Gamma1 = ((1-x1)^2)*( (tau21* (G21/(x1 + (1-x1)*G21))^2) + ((tau12*G12)/( 1- x1 + x1*G12)^2)); 

    Gamma1 =  exp(Gamma1);    


    %B1 = -0.0147*T^2 + 11.513*T - 2432.2; %cm^3/mol
    B1 = - 0.0102 * T * T + 8.7196 * T - 1994.1 ; 

    P = 0.5;
    while(1)
        y = exp(log(x1*Gamma1)+log(P1_s) - ((P-P1_s)*(B1 - V1))/(R*T));
        if(abs(y-P)<0.001)
            P = y;
            break
        end
        P = y;
    end

ARD = ARD + abs( P - PP(i));  
end
ARD = ARD / length(TT) * 100