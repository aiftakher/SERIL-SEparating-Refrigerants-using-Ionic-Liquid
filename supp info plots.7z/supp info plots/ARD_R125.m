clc
clear all
close all
mat = xlsread('data_emimAc_R125.xlsx');
TT = mat(:,1);
PP = mat(:,2);
XX = mat(:,3);
ARD = 0;
for i= 1:length(TT)
    T = TT(i);
    R = 8.314;
    A1 = 9.15935;
    B1 = 2966.36;
    C1 = 37.4124;
    a = 0.531;
    P1_s = exp(A1 - B1/(T+C1)); %Mpa
    V0 = 170.21 / (1.277 -0.0006*T); %cm^3/mol
    V1 = (1 - a)*V0;
    x1 = XX(i);		



	%tau120 = -11.25602443;
    %tau121 = -6.54404274;
    %tau210 = 1.64344648;
    %tau211 = 2.8860335;
			
    			
			
			
    tau120 = -0.90333103;
    tau121 = -0.66955102;
    tau210 = 1.74814509;
    tau211 = 1.45575707;

    tau12 = tau120 + tau121/T;
    tau21 = tau210 + tau211/T;

    G12 = exp(-0.2*tau12);
    G21 = exp(-0.2*tau21);

    Gamma1 = ((1-x1)^2)*( (tau21* (G21/(x1 + (1-x1)*G21))^2) + ((tau12*G12)/( 1- x1 + x1*G12)^2)); 

    Gamma1 =  exp(Gamma1);    


    B1 = - 0.0115 * T * T + 9.8346 * T - 2282.5 ;
    P = 0.5;
    while(1)
        y = exp(log(x1*Gamma1)+log(P1_s) - ((P-P1_s)*(B1 - V1))/(R*T));
        if(abs(y-P)<0.001)
            P = y;
            break
        end
        P = y;
    end

ARD = ARD + abs( P - PP(i));  
end
ARD = ARD / length(TT) * 100