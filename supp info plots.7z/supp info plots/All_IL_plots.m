clc
clear all
close all
mat = xlsread('IL_properties.xlsx');
ith = 7;
for index = ith:ith
    rep = 1;
    disp(index)
    t = [303.15 323.15 343.15];
    for i = 1:3
        T = t(i);
        R = 8.314;
        A1 = 9.49117;
        B1 = 3006.86;
        C1 = 37.1416;
        a = 0.750;
        P1_s = exp(A1 - B1/(T+C1)); %Mpa
        V0 = mat(index,5) / (mat(index,6) + mat(index,7)*T); %cm^3/mol
        V1 = (1 - a)*V0;
        id = 1;
        Pressure1 = [];
        X1 = [];
        for x1 = 0.005:0.05:0.8

            %if((i==3  && x1 > 0.1) || (i==2  && x1 > 0.2))
            %   continue
            %end

            tau120 = mat(index,1);
            tau121 = mat(index,2);
            tau210 = mat(index,3);
            tau211 = mat(index,4);
    
            tau12 = tau120 + tau121/T;
            tau21 = tau210 + tau211/T;
    
            G12 = exp(-0.2*tau12);
            G21 = exp(-0.2*tau21);
    
            Gamma1 = ((1-x1)^2)*( (tau21* (G21/(x1 + (1-x1)*G21))^2) + ((tau12*G12)/( 1- x1 + x1*G12)^2)); 
    
            Gamma1 =  exp(Gamma1);    
    
    
            %B1 = -0.0147*T^2 + 11.513*T - 2432.2; %cm^3/mol
            B1 = - 0.0102 * T * T + 8.7196 * T - 1994.1 ; 

            P = 0.5;
            while(1)
                y = exp(log(x1*Gamma1)+log(P1_s) - ((P-P1_s)*(B1 - V1))/(R*T));
                if(abs(y-P)<0.001)
                    Pressure1(id) = y;
                    X1(id) = x1;
                    id = id + 1;
                    break
                end
                P = y;
            end        
    
        end
       
% if(index==1)
%             plot(X1',Pressure1','-o','Color',[0 0.4470 0.7410],'LineWidth',5);
%             hold on
%         elseif(index==2)
%             plot(X1',Pressure1','->','Color',[0.8500 0.3250 0.0980],'LineWidth',5);
%             hold on
%         elseif(index==3)
%             plot(X1',Pressure1','-s','Color',[0.9290 0.6940 0.1250],'LineWidth',5);
%             hold on
%         elseif(index==4)
%             plot(X1',Pressure1','-d','Color',[0.4940 0.1840 0.5560],'LineWidth',5);
%             hold on
%         elseif(index==5)
%             plot(X1',Pressure1','-p','Color',[0.4660 0.6740 0.1880],'LineWidth',5);
%             hold on
%         elseif(index==6)
%             plot(X1',Pressure1','-h','Color',[0.6350 0.0780 0.1840],'LineWidth',5);
%             hold on
%         end



        if(rep==1)           
            %legend('T = 298.15 K');
            plot(X1',Pressure1','-','Color',[0.4660 0.6740 0.1880],'LineWidth',3);
            hold on
            rep = rep + 1;
        elseif(rep==2)
            %legend('T = 333.15 K');       
            plot(X1',Pressure1','-','Color',[0.4940 0.1840 0.5560],'LineWidth',3);
            hold on
            rep = rep + 1; 
        elseif(rep==3)
            %legend('T = 373.15 K');   
            plot(X1',Pressure1','-','Color',[0.6350 0.0780 0.1840],'LineWidth',3);
            hold on
            rep = rep + 1;
        end
    end    
end
ax = gca;
ax.FontSize = 14;
xlabel('R-32 mole fraction in IL', 'FontSize',18, FontWeight='bold',FontName='arial');
ylabel('Pressure (MPa)','FontSize',18,FontWeight='bold',FontName='arial');
lgd = legend({'T = 303.15 K','T = 323.15 K','T = 343.15 K'},'Location','east','NumColumns',1);
lgd.FontSize=14;
xlim([0 1])
ylim([0 1])
daspect([1 1.2 1])
name = num2str(ith);
saveas(gcf,name,'png')

figure

ith = ith+1;
for index = ith:ith
    rep = 1;
    disp(index)
    t = [303.15 323.15 343.15];
    for i = 1:3
        T = t(i);
        R = 8.314;
        A1 = 9.15935;
        B1 = 2966.36;
        C1 = 37.4124;
        a = 0.531;
        P1_s = exp(A1 - B1/(T+C1)); %Mpa
        V0 = mat(index,5) / (mat(index,6) + mat(index,7)*T); %cm^3/mol
        V1 = (1 - a)*V0;
        id = 1;
        Pressure1 = [];
        X1 = [];
        for x1 = 0.005:0.05:1

            if((i==3  && x1 > 0.9) || (i==2  && x1 > 0.9)) 
               continue
            end
                  
            tau120 = mat(index,1);
            tau121 = mat(index,2);
            tau210 = mat(index,3);
            tau211 = mat(index,4);
    
            tau12 = tau120 + tau121/T;
            tau21 = tau210 + tau211/T;
    
            G12 = exp(-0.2*tau12);
            G21 = exp(-0.2*tau21);
    
            Gamma1 = ((1-x1)^2)*( (tau21* (G21/(x1 + (1-x1)*G21))^2) + ((tau12*G12)/( 1- x1 + x1*G12)^2)); 
    
            Gamma1 =  exp(Gamma1);    
    
    
            %B1 = -0.0162*T^2 + 12.832*T - 2752.5; %cm^3/mol
            B1 = - 0.0115 * T * T + 9.8346 * T - 2282.5 ;
            P = 0.5;
            while(1)
                y = exp(log(x1*Gamma1)+log(P1_s) - ((P-P1_s)*(B1 - V1))/(R*T));
                if(abs(y-P)<0.001)
                    Pressure1(id) = y;
                    X1(id) = x1;
                    id = id + 1;
                    break
                end
                P = y;
            end        
    
        end
        
        if(rep==1)           
            %legend('T = 298.15 K');
            plot(X1',Pressure1','-','Color',[0.4660 0.6740 0.1880],'LineWidth',3);
            hold on
            rep = rep + 1;
        elseif(rep==2)
            %legend('T = 333.15 K');       
            plot(X1',Pressure1','-','Color',[0.4940 0.1840 0.5560],'LineWidth',3);
            hold on
            rep = rep + 1; 
        elseif(rep==3)
            %legend('T = 373.15 K');   
            plot(X1',Pressure1','-','Color',[0.6350 0.0780 0.1840],'LineWidth',3);
            hold on
            rep = rep + 1;
        end
    end    
end
ax = gca;
ax.FontSize = 14;
xlabel('R-125 mole fraction in IL', 'FontSize',18, FontWeight='bold',FontName='arial');
ylabel('Pressure (MPa)','FontSize',18,FontWeight='bold',FontName='arial');
lgd = legend({'T = 303.15 K','T = 323.15 K','T = 343.15 K'},'Location','east','NumColumns',1);
lgd.FontSize = 14;
xlim([0 1])
ylim([0 1])
daspect([1 1.2 1])
name = num2str(ith);
saveas(gcf,name,'png')
